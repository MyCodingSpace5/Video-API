package com.example.fragmentsanddatabindingpy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.fragmentsanddatabindingpy.databinding.ActivityMainBinding;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding mainBinding;
    ArrayList<Image> frames;
    Boolean playbackisTrue;

    Boolean fastfowardEnabled;

    Integer fastfowardmutiplier;

    Boolean rewindEnabled;

    Integer rewindMutliper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        frames = new ArrayList<>();
        Video v1 = new Video("Captioning", frames);
        mainBinding.setVideo(v1);
        Image v;
            for(int i = 0; i == frames.size();){
                if(playbackisTrue == true && fastfowardEnabled == false){
                    v = v1.getVideo(i);
                    mainBinding.setSecImage(v);
                    i++;
                    if(playbackisTrue == true && fastfowardEnabled == true){
                        v = v1.getVideo(i);
                        mainBinding.setSecImage(v);
                        i+=fastfowardmutiplier;
                    }
                    if(playbackisTrue == true && rewindEnabled == true){
                        v = v1.getVideo(i);
                        mainBinding.setSecImage(v);
                        i-=rewindMutliper;
                    }
                }
                else if(playbackisTrue == false){
                    v = v1.getVideo(i);
                    mainBinding.setSecImage(v);
                }

            }



    }

}