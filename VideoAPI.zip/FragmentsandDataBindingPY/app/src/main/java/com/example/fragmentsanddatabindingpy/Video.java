package com.example.fragmentsanddatabindingpy;

import android.media.Image;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;



public class Video {
    private String subtitles;
    private ArrayList<Image> newstart = new ArrayList<>();

    public Video(String closedcaptioning, ArrayList<Image> movingimageviews){
        this.subtitles = closedcaptioning;
        this.newstart = movingimageviews;
    }

    public String getSubtitles() {
        return subtitles;
    }

    public void setSubtitles(String subtitles) {
        this.subtitles = subtitles;
    }

    public Image getVideo(int position) {
        return newstart.get(position);
    }

    public void setVideo(ArrayList<Image> video) {
        this.newstart = video;
    }

}
