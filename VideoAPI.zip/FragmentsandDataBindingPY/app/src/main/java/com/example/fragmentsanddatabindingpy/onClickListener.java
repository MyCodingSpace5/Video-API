package com.example.fragmentsanddatabindingpy;

import android.view.View;

public class onClickListener{
    public View view;

    public onClickListener(View view) {
        this.view = view;
    }
    public void onButtonClicked(View view){

    }
}
